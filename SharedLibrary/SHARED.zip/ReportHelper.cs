namespace SharedLibrary;

public class ReportHelper
{
	public int From { get; set; }
	public int To { get; set; }
	public string Email { get; set; }
}