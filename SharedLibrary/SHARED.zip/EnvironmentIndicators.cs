namespace SharedLibrary;

public class EnvironmentIndicators
{
	public int Id { get; set; }
	public string ReadTime { get; set; }
	public float Pressure { get; set; }
	public float Humidity { get; set; }
	public float Temperature { get; set; }
}